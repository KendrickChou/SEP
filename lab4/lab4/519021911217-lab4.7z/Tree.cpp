#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <iostream>
#include <fstream>
#include <limits.h>
#include <vector>
#include <queue>
#include <algorithm>

#include "Tree.h"

using namespace std;

/****************************************************************
 *                    Write your code below
 ****************************************************************/
TreeNode::TreeNode(int x,int y){
    data[0] = x;
    data[1] = y;
}

int TreeNode::getX(){
    return this->data[0];
}

int TreeNode::getY(){
    return this->data[1];
}

TreeNode::~TreeNode(){
}

/* ************************************ */

BinaryDimonTree::BinaryDimonTree(){
    root = nullptr;
}

TreeNode* BinaryDimonTree::find_nearest_node(int x,int y){
    TreeNode *cur = root;
    TreeNode *guess = nullptr;
    float min_distance = 900000000;
    TreeNode *test = new TreeNode(x,y);
    recur_search(cur,test,min_distance,&guess,0);
    return guess;
}

float distance(TreeNode *node1, TreeNode *node2){
    float dis;
    int X = (node1->data[0] - node2->data[0]) * (node1->data[0] - node2->data[0]);
    int Y = (node1->data[1] - node2->data[1]) * (node1->data[1] - node2->data[1]);
    dis = sqrt(X+Y);
    return dis;
}

void recur_search(TreeNode *cur, TreeNode *test, float &min_distance, TreeNode **guess,bool digit){
    if(cur == nullptr) return;
    float cur_dis = distance(cur,test);
   if(cur_dis < min_distance){
       min_distance = cur_dis;
       *guess = cur;
   }
   else if(cur_dis == min_distance){
       if(cur->data[0] < (*guess)->data[0]){
           *guess = cur;
       }
       else if(cur->data[0] == (*guess)->data[0] && cur->data[1] < (*guess)->data[1]){
           *guess = cur;
       }
   }
   if(cur->data[digit] > test->data[digit]){
       recur_search(cur->lnode,test,min_distance,guess,!digit);
       if(min_distance >= (cur->data[digit] - test->data[digit])){
           recur_search(cur->rnode,test,min_distance,guess,!digit);
       }
   }
   else{
       recur_search(cur->rnode,test,min_distance,guess,!digit);
       if(min_distance >= (test->data[digit] - cur->data[digit])){
           recur_search(cur->lnode,test,min_distance,guess,!digit);
       }
   }
}

istream &operator>>(istream &in, BinaryDimonTree &tree){
    int num_node,x,y;
    char blank;
    num_node = in.get();
    blank = in.get();
//    printf("***%c***\n",num_node);
    for(int i = 0; i < (num_node - '0'); ++i){
        string line;
        bool flag = true;
        getline(in,line);
        int size = line.size();
        int cnt = 0;
        while(cnt < size){
            char c = line[cnt];
            if(line[cnt] == '-'){
                ++cnt;
                if(flag) {
                    x = 0 - line[cnt] + '0';
                    flag = false;
                }
                else y = 0 - line[cnt] + '0';
                ++cnt;
            }
            else if(line[cnt] == ' '){
                ++cnt;
                continue;
            }
            else{
                if(flag) {
                    x = line[cnt] - '0';
                    ++cnt;
                    flag = false;
                }
                else {
                    y = line[cnt] - '0';
                    ++cnt;
                }
            }
        }
//        printf("***%d***%d***\n",x,y);
        tree.insert(x,y);
    }
}

void BinaryDimonTree::insert(int x, int y){
    TreeNode *newNode = new TreeNode(x,y);
    if(root == nullptr) {
        root = newNode;
        return;
    }
    insert(root, newNode, 0);
}

void BinaryDimonTree::insert(TreeNode *root, TreeNode *newNode, bool comDigit){
        if(root->data[comDigit] > newNode->data[comDigit]){
            if(root->lnode == nullptr){
                root->lnode = newNode;
                return;
            }
            else{
                insert(root->lnode, newNode, !comDigit);
            }
        }
        else{
            if(root->rnode == nullptr){
                root->rnode = newNode;
                return;
            }
            else{
                insert(root->rnode, newNode, !comDigit);
            }
        }
}

BinaryDimonTree::~BinaryDimonTree(){
    deleteTree();
}

void BinaryDimonTree::deleteTree(){
    deleteTree(root);
}

void BinaryDimonTree::deleteTree(TreeNode *root){
    if(root->lnode == nullptr && root->rnode == nullptr){
        delete root;
        return;
    }
    else{
        if(root->lnode != nullptr){
            deleteTree(root->lnode);
            root->lnode = nullptr;
        }
        if(root->rnode != nullptr){
            deleteTree(root->rnode);
            root->rnode = nullptr;
        }
    }
}

void BinaryDimonTree::showTree(TreeNode *root){
    if(root->lnode != nullptr){
        showTree(root->lnode);
    }
    printf("***%d***%d***\n",root->data[0],root->data[1]);
    if(root->rnode != nullptr){
        showTree(root->rnode);
    }
}

void BinaryDimonTree::show(){
    showTree(root);
}
